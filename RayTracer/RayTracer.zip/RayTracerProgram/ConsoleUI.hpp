#pragma once

class ConsoleUI final
{
public:
	ConsoleUI() = delete;
	static void runRayTracer();
};