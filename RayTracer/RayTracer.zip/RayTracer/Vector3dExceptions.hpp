#pragma once

#include <exception>

class NormalIsZero final : std::exception{};
