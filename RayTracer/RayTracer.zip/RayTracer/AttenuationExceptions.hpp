#pragma once

#include <exception>

class AttenuationCoefficientOutOfRange final :std::exception {};