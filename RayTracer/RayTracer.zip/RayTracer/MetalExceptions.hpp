#pragma once
#include <exception>

class FuzzOutOfRange: std::exception{};
