#pragma once
#include <exception>

class IncorrectNumberOfPixels : std::exception{};
